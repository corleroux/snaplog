﻿SNAPLOG CAPACITOR ICONS
======================
Source base: docs/brand (snaplog-icon-*.svg masters)

iOS / PWA
- icon-1024.png : App Store 1024x1024, no alpha, full-bleed Ink #16150F
- icon-512.png / icon-192.png : PWA manifest
- apple-touch-icon-180.png : iOS home screen 180x180
- icon-48.png : favicon-ish small size

Android adaptive (API 26+)
- android-fg.svg / android-fg-432.png : foreground, transparent artwork centred in 432dp canvas
- android-bg.svg / android-bg-432.png : background, flat #16150F, no gradient

Generate mipmaps + splash:
  npx capacitor-assets generate --iconBackgroundColor "#16150F" --splashBackgroundColor "#16150F"
